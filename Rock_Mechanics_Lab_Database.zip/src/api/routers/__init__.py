# src/api/routers/__init__.py
from fastapi import APIRouter

router = APIRouter()
