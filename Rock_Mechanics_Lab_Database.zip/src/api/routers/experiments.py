# src/api/routers/experiments.py

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from services.experiment_service import ExperimentService
from scripts.reduction_script import (
    process_vertical_load_measurements,
    process_horizontal_load_measurements,
    process_load_point_displacement,
    process_layer_thickness,
    calculate_gouge_area_from_blocks_dimensions
)

router = APIRouter()
experiment_service = ExperimentService()

class Gouge(BaseModel):
    gouge_id: str

class Block(BaseModel):
    block_id: str

class ExperimentCreateRequest(BaseModel):
    experiment_id: str
    experiment_type: str
    gouges: List[Gouge]
    core_sample_id: str
    blocks: List[Block]
    centralized_measurements: List[Dict]
    additional_measurements: List[Dict]

@router.post("/", response_model=dict)
def create_experiment(request: ExperimentCreateRequest):
    try:
        experiment_service.create_experiment(
            experiment_id=request.experiment_id,
            experiment_type=request.experiment_type,
            gouges=[g.model_dump() for g in request.gouges],
            core_sample_id=request.core_sample_id,
            blocks=[b.model_dump() for b in request.blocks],
            centralized_measurements=request.centralized_measurements,
            additional_measurements=request.additional_measurements
        )
        return {"message": f"Experiment {request.experiment_id} created successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/{experiment_id}", response_model=dict)
def get_experiment(experiment_id: str):
    try:
        experiment = experiment_service.get_experiment_by_id(experiment_id)
        if experiment:
            return experiment
        else:
            raise HTTPException(status_code=404, detail="Experiment not found")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

class ExperimentReductionRequest(BaseModel):
    experiment_id: str
    machine_id: str
    layer_thickness_measured_mm: Optional[float] = None
    layer_thickness_measured_point: Optional[int] = 0

class ExperimentReductionResponse(BaseModel):
    shear_stress_MPa: List[float]
    normal_stress_MPa: List[float]
    load_point_displacement_mm: List[float]
    layer_thickness_mm: List[float]

@router.post("/reduce_experiment", response_model=ExperimentReductionResponse)
def reduce_experiment(data: ExperimentReductionRequest):
    experiment_id = data.experiment_id
    machine_id = data.machine_id
    layer_thickness_measured_mm = data.layer_thickness_measured_mm or 6
    layer_thickness_measured_point = data.layer_thickness_measured_point

    experiment_info = experiment_service.get_experiment_by_id(experiment_id)
    if not experiment_info:
        raise HTTPException(status_code=404, detail="Experiment not found")
    
    experiment_date = experiment_info['Start_Datetime']
    gouge_area = calculate_gouge_area_from_blocks_dimensions(experiment_id=experiment_id)
    
    shear_stress_MPa = process_vertical_load_measurements(
        experiment_id=experiment_id,
        machine_id=machine_id,
        experiment_date=experiment_date,
        gouge_area=gouge_area
    )
    
    normal_stress_MPa = process_horizontal_load_measurements(
        experiment_id=experiment_id,
        machine_id=machine_id,
        experiment_date=experiment_date,
        gouge_area=gouge_area
    )
    
    load_point_displacement_mm = process_load_point_displacement(
        experiment_id=experiment_id,
        machine_id=machine_id,
        experiment_date=experiment_date
    )
    
    layer_thickness_mm = process_layer_thickness(
        experiment_id=experiment_id,
        machine_id=machine_id,
        experiment_date=experiment_date,
        layer_thickness_measured_mm=layer_thickness_measured_mm,
        layer_thickness_measured_point=layer_thickness_measured_point
    )

    return ExperimentReductionResponse(
        shear_stress_MPa=shear_stress_MPa.tolist(),
        normal_stress_MPa=normal_stress_MPa.tolist(),
        load_point_displacement_mm=load_point_displacement_mm.tolist(),
        layer_thickness_mm=layer_thickness_mm.tolist()
    )
